package com.example.lmsbackend.models;

public enum ERole {
    ROLE_STUDENT,
    ROLE_INSTRUCTOR,
    ROLE_ADMIN
}