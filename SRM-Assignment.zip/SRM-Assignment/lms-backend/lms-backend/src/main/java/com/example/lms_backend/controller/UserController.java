package com.example.lmsbackend.controller;

import com.example.lmsbackend.models.Course;
import com.example.lmsbackend.models.User;
import com.example.lmsbackend.repository.UserRepository;
import com.example.lmsbackend.security.services.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @GetMapping("/me/courses")
    public ResponseEntity<?> getMyEnrolledCourses() {
        // Get the logged-in user's details
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
        // Find the user in the database
        User user = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Get their enrolled courses
        Set<Course> enrolledCourses = user.getEnrolledCourses();
        return ResponseEntity.ok(enrolledCourses);
    }
}