package com.example.lmsbackend.controller;

import com.example.lmsbackend.models.Course;
import com.example.lmsbackend.models.Review;
import com.example.lmsbackend.models.User;
import com.example.lmsbackend.payload.request.ReviewRequest;
import com.example.lmsbackend.payload.response.MessageResponse;
import com.example.lmsbackend.repository.CourseRepository;
import com.example.lmsbackend.repository.ReviewRepository;
import com.example.lmsbackend.repository.UserRepository;
import com.example.lmsbackend.security.services.UserDetailsImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    CourseRepository courseRepository;

    @Autowired
    UserRepository userRepository;
    
    @Autowired
    ReviewRepository reviewRepository;

    @GetMapping("/public")
    public ResponseEntity<List<Course>> getAllCoursesPublic() {
        List<Course> courses = courseRepository.findAll();
        return ResponseEntity.ok(courses);
    }
    
    @GetMapping("/{id}/reviews/public")
    public ResponseEntity<List<Review>> getCourseReviewsPublic(@PathVariable Long id) {
        List<Review> reviews = reviewRepository.findByCourseId(id);
        return ResponseEntity.ok(reviews);
    }

    @PostMapping
    @PreAuthorize("hasRole('INSTRUCTOR')")
    public ResponseEntity<?> createCourse(@Valid @RequestBody Course course) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User instructor = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("Error: User not found."));

        course.setInstructor(instructor);
        Course savedCourse = courseRepository.save(course);
        return new ResponseEntity<>(savedCourse, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('INSTRUCTOR')")
    public ResponseEntity<?> updateCourse(@PathVariable Long id, @Valid @RequestBody Course courseDetails) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error: Course not found."));

        if (!course.getInstructor().getId().equals(userDetails.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new MessageResponse("Error: You are not authorized to update this course."));
        }

        course.setTitle(courseDetails.getTitle());
        course.setDescription(courseDetails.getDescription());
        course.setPrice(courseDetails.getPrice());
        course.setThumbnail(courseDetails.getThumbnail());

        Course updatedCourse = courseRepository.save(course);
        return ResponseEntity.ok(updatedCourse);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('INSTRUCTOR') or hasRole('ADMIN')")
    public ResponseEntity<?> deleteCourse(@PathVariable Long id) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error: Course not found."));

        boolean isInstructor = course.getInstructor().getId().equals(userDetails.getId());
        boolean isAdmin = userDetails.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        if (!isInstructor && !isAdmin) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new MessageResponse("Error: You are not authorized to delete this course."));
        }

        courseRepository.delete(course);
        return ResponseEntity.ok(new MessageResponse("Course deleted successfully!"));
    }

    @PostMapping("/{id}/enroll")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<?> enrollInCourse(@PathVariable Long id) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User student = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("Error: User not found."));

        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error: Course not found."));
        
        student.getEnrolledCourses().add(course);
        userRepository.save(student);
        
        return ResponseEntity.ok(new MessageResponse("Enrolled in course successfully!"));
    }

    @PostMapping("/{id}/reviews")
    @PreAuthorize("hasRole('STUDENT')")
    public ResponseEntity<?> addReview(@PathVariable Long id, @Valid @RequestBody ReviewRequest reviewRequest) {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User student = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RuntimeException("Error: User not found."));

        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error: Course not found."));

        if (!student.getEnrolledCourses().contains(course)) {
             return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new MessageResponse("Error: You must be enrolled to review this course."));
        }
        
        Review review = new Review();
        review.setRating(reviewRequest.getRating());
        review.setComment(reviewRequest.getComment());
        review.setCourse(course);
        review.setUser(student);
        
        reviewRepository.save(review);
        
        return new ResponseEntity<>(review, HttpStatus.CREATED);
    }
}