package com.example.lmsbackend;

import com.example.lmsbackend.models.ERole;
import com.example.lmsbackend.models.Role;
import com.example.lmsbackend.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    RoleRepository roleRepository;

    @Override
    public void run(String... args) throws Exception {
        // This will run once on startup
        
        if (roleRepository.findByName(ERole.ROLE_STUDENT).isEmpty()) {
            roleRepository.save(new Role(ERole.ROLE_STUDENT));
        }
        if (roleRepository.findByName(ERole.ROLE_INSTRUCTOR).isEmpty()) {
            roleRepository.save(new Role(ERole.ROLE_INSTRUCTOR));
        }
        if (roleRepository.findByName(ERole.ROLE_ADMIN).isEmpty()) {
            roleRepository.save(new Role(ERole.ROLE_ADMIN));
        }
    }
}