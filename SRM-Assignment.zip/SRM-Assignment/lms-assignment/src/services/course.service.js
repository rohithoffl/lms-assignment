import axios from 'axios';
import authHeader from './auth-header';

const API_URL = 'http://localhost:8080/api/courses/';
const USER_API_URL = 'http://localhost:8080/api/users/';


const getAllPublicCourses = () => {
  return axios.get(API_URL + 'public');
};

const getCourseReviews = (courseId) => {
  return axios.get(API_URL + courseId + '/reviews/public');
};

// --- Student Actions ---
const enrollInCourse = (courseId) => {
  return axios.post(API_URL + courseId + '/enroll', {}, { headers: authHeader() });
};

const addReview = (courseId, rating, comment) => {
  return axios.post(API_URL + courseId + '/reviews', { rating, comment }, { headers: authHeader() });
};

// --- Instructor Actions ---
const createCourse = (courseData) => {
  // courseData should be { title, description, price, thumbnail }
  return axios.post(API_URL, courseData, { headers: authHeader() });
};

// --- THIS IS THE FIX FOR "MY COURSES" ---
// Make sure you add this endpoint to your backend!
const getMyEnrolledCourses = () => {
  // You'll need to create this backend endpoint:
  // @GetMapping("/me/courses")
  // public ResponseEntity<?> getMyCourses(Authentication auth) { ... }
  return axios.get(USER_API_URL + 'me/courses', { headers: authHeader() });
};


const CourseService = {
  getAllPublicCourses,
  getCourseReviews,
  enrollInCourse,
  addReview,
  createCourse,
  getMyEnrolledCourses,
};

export default CourseService;