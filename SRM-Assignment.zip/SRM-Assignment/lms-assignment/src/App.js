import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'; // Your new CSS

import AuthService from './services/auth.service';

import Login from './components/Login';
import Signup from './components/Signup';
import CourseList from './components/CourseList';
import CourseDetail from './components/CourseDetail';
import MyCourses from './components/MyCourses';
import InstructorDashboard from './components/InstructorDashboard';
import AdminDashboard from './components/AdminDashboard';
import ProtectedRoute from './common/ProtectedRoute';

function App() {
  const [currentUser, setCurrentUser] = useState(undefined);
  const navigate = useNavigate();

  useEffect(() => {
    const user = AuthService.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const logOut = () => {
    AuthService.logout();
    setCurrentUser(undefined);
    navigate('/');
  };

  // Helper booleans for roles
  const isStudent = currentUser?.roles.includes('ROLE_STUDENT');
  const isInstructor = currentUser?.roles.includes('ROLE_INSTRUCTOR');
  const isAdmin = currentUser?.roles.includes('ROLE_ADMIN');

  return (
    <div>
      <nav className="navbar navbar-expand navbar-dark bg-dark">
        <Link to={'/'} className="navbar-brand">
          LMS
        </Link>
        <div className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link to={'/'} className="nav-link">
              Courses
            </Link>
          </li>

          {isStudent && (
            <li className="nav-item">
              <Link to={'/my-courses'} className="nav-link">
                My Courses
              </Link>
            </li>
          )}

          {isInstructor && (
            <li className="nav-item">
              <Link to={'/instructor'} className="nav-link">
                Instructor Dashboard
              </Link>
            </li>
          )}

          {isAdmin && (
            <li className="nav-item">
              <Link to={'/admin'} className="nav-link">
                Admin Dashboard
              </Link>
            </li>
          )}
        </div>

        {currentUser ? (
          <div className="navbar-nav ms-auto">
            <li className="nav-item">
              <a href="#" className="nav-link">
                {currentUser.username}
              </a>
            </li>
            <li className="nav-item">
              <a href="/login" className="nav-link" onClick={logOut}>
                Log Out
              </a>
            </li>
          </div>
        ) : (
          <div className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link to={'/login'} className="nav-link">
                Login
              </Link>
            </li>
            <li className="nav-item">
              <Link to={'/signup'} className="nav-link">
                Sign Up
              </Link>
            </li>
          </div>
        )}
      </nav>

      <div className="container mt-3">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<CourseList />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/course/:id" element={<CourseDetail />} />

          {/* Protected Routes */}
          <Route
            path="/my-courses"
            element={
              <ProtectedRoute roles={['ROLE_STUDENT']}>
                <MyCourses />
              </ProtectedRoute>
            }
          />
          <Route
            path="/instructor"
            element={
              <ProtectedRoute roles={['ROLE_INSTRUCTOR']}>
                <InstructorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute roles={['ROLE_ADMIN']}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
        </Routes>
      </div>
    </div>
  );
}

export default App;