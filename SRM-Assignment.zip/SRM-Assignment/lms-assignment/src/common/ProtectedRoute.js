import React from 'react';
import { Navigate } from 'react-router-dom';
import AuthService from '../services/auth.service';

const ProtectedRoute = ({ children, roles }) => {
  const currentUser = AuthService.getCurrentUser();

  // 1. Check if user is logged in
  if (!currentUser) {
    // Not logged in, redirect to login page
    return <Navigate to="/login" />;
  }

  // 2. Check if route requires roles and if user has one of them
  if (roles && !roles.some((role) => currentUser.roles.includes(role))) {
    // Role not authorized, redirect to home page
    return <Navigate to="/" />;
  }

  // 3. User is logged in and authorized
  return children;
};

export default ProtectedRoute;