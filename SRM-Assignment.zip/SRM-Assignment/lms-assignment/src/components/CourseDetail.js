import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import CourseService from '../services/course.service';
import AuthService from '../services/auth.service';

const CourseDetail = () => {
  const location = useLocation();
  const { course: initialCourseData } = location.state || {};
  const { id } = useParams();

  // Use state to hold the course data
  const [course, setCourse] = useState(initialCourseData);
  const [reviews, setReviews] = useState([]);
  const [message, setMessage] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  const currentUser = AuthService.getCurrentUser();
  const isStudent = currentUser?.roles.includes('ROLE_STUDENT');

  useEffect(() => {
    // If course data wasn't passed, fetch it (e.g., on page refresh)
    if (!course) {
      CourseService.getAllPublicCourses().then(res => {
        const foundCourse = res.data.find(c => c.id.toString() === id);
        setCourse(foundCourse);
      });
    }

    // Fetch reviews
    CourseService.getCourseReviews(id)
      .then((response) => {
        setReviews(response.data);
      })
      .catch((error) => console.error('Error fetching reviews:', error));
  }, [id, course]);

  const handleEnroll = () => {
    CourseService.enrollInCourse(id)
      .then((response) => {
        setMessage('Enrollment successful!');
      })
      .catch((error) => {
        setMessage('Error enrolling: ' + (error.response?.data?.message || 'Please try again.'));
      });
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    CourseService.addReview(id, reviewRating, reviewComment)
      .then((response) => {
        setMessage('Review submitted!');
        setReviews([...reviews, response.data]); // Add new review to list
        setReviewRating(5);
        setReviewComment('');
      })
      .catch((error) => {
        setMessage('Error submitting review: ' + (error.response?.data?.message || 'Are you enrolled?'));
      });
  };

  if (!course) {
    return <div>Loading course details...</div>;
  }

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-8">
          <h2 className="display-5">{course.title}</h2>
          <p className="lead">{course.description}</p>
          <hr />
          <h4>Reviews</h4>
          {reviews.length > 0 ? (
            <ul className="list-group">
              {reviews.map((review) => (
                <li key={review.id} className="list-group-item">
                  <strong>Rating: {'⭐'.repeat(review.rating)}</strong>
                  <p className="mb-0">{review.comment}</p>
                  <small>by {review.user?.username || 'Anonymous'}</small>
                </li>
              ))}
            </ul>
          ) : (
            <p>No reviews yet.</p>
          )}
        </div>
        <div className="col-md-4">
          <div className="card">
            <img src={course.thumbnail || 'https://via.placeholder.com/300x200'} className="card-img-top" alt={course.title} />
            <div className="card-body">
              <h5 className="card-title display-6">${course.price}</h5>
              {isStudent && (
                <button className="btn btn-success w-100" onClick={handleEnroll}>
                  Enroll Now
                </button>
              )}
              {message && <div className="alert alert-info mt-2">{message}</div>}
            </div>
          </div>

          {isStudent && (
            <div className="mt-4 card p-3">
              <h5>Leave a Review</h5>
              <form onSubmit={handleReviewSubmit}>
                <div className="form-group">
                    <label>Rating</label>
                    <select className="form-control" value={reviewRating} onChange={(e) => setReviewRating(e.target.value)}>
                        <option value="5">5 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="2">2 Stars</option>
                        <option value="1">1 Star</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Comment</label>
                    <textarea className="form-control" rows="3" value={reviewComment} onChange={(e) => setReviewComment(e.target.value)}></textarea>
                </div>
                <button type="submit" className="btn btn-primary mt-2">Submit</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;