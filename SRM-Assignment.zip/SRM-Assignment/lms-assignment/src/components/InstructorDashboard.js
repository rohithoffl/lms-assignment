import React, { useState } from 'react';
import CourseService from '../services/course.service';

const InstructorDashboard = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState(0);
  const [thumbnail, setThumbnail] = useState('');
  const [message, setMessage] = useState('');

  const handleCreateCourse = (e) => {
    e.preventDefault();
    setMessage('');

    const courseData = { title, description, price: parseFloat(price), thumbnail };

    CourseService.createCourse(courseData)
      .then((response) => {
        setMessage('Course created successfully!');
        // Clear form
        setTitle('');
        setDescription('');
        setPrice(0);
        setThumbnail('');
      })
      .catch((error) => {
        setMessage('Error creating course: ' + error.response.data.message);
      });
  };

  return (
    <div>
      <h3>Instructor Dashboard</h3>
      <hr />
      <h4>Create New Course</h4>
      <form onSubmit={handleCreateCourse}>
        <div className="form-group mb-2">
          <label>Title</label>
          <input
            type="text"
            className="form-control"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="form-group mb-2">
          <label>Description</label>
          <textarea
            className="form-control"
            rows="3"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          ></textarea>
        </div>
        <div className="form-group mb-2">
          <label>Price ($)</label>
          <input
            type="number"
            className="form-control"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
            min="0"
          />
        </div>
        <div className="form-group mb-2">
          <label>Thumbnail Image URL</label>
          <input
            type="text"
            className="form-control"
            value={thumbnail}
            onChange={(e) => setThumbnail(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary mt-3">
          Create Course
        </button>
        {message && <div className="alert alert-info mt-3">{message}</div>}
      </form>

      {/* TODO: Add a list of courses created by this instructor */}
    </div>
  );
};

export default InstructorDashboard;