import React, { useState, useEffect } from 'react';
import CourseService from '../services/course.service';
import { Link } from 'react-router-dom';

const MyCourses = () => {
  const [myCourses, setMyCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // This requires the backend endpoint!
    CourseService.getMyEnrolledCourses()
      .then((response) => {
        setMyCourses(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching enrolled courses:', error);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading your courses...</p>;

  return (
    <div>
      <h3>My Enrolled Courses</h3>
      {myCourses.length > 0 ? (
        <ul className="list-group">
          {myCourses.map((course) => (
            <li key={course.id} className="list-group-item d-flex justify-content-between align-items-center">
                {course.title}
                <Link 
                  to={'/course/' + course.id}
                  state={{ course: course }}
                  className="btn btn-primary btn-sm">
                  Go to Course
                </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p>You are not enrolled in any courses yet.</p>
      )}
    </div>
  );
};

export default MyCourses;