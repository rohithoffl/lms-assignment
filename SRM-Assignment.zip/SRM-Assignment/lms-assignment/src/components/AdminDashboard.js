import React, { useState, useEffect } from 'react';
import AdminService from '../services/admin.service';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    AdminService.getAllUsers()
      .then((response) => {
        setUsers(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching users:', error);
        setLoading(false);
      });
  }, []);

  // TODO: Add delete user/course handlers

  if (loading) return <p>Loading admin data...</p>;

  return (
    <div>
      <h3>Admin Dashboard</h3>
      <hr />
      <h4>Manage Users</h4>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Roles</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.username}</td>
              <td>{user.email}</td>
              <td>{user.roles.map((role) => role.name.replace('ROLE_', '')).join(', ')}</td>
              <td>
                <button className="btn btn-danger btn-sm">Delete User</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* TODO: Add a table for "Manage Courses" */}
    </div>
  );
};

export default AdminDashboard;