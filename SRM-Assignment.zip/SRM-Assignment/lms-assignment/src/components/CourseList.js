import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CourseService from '../services/course.service';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    CourseService.getAllPublicCourses()
      .then((response) => {
        setCourses(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching courses:', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div>Loading courses...</div>;
  }

  return (
    <div className="container">
      <header className="p-3 my-3 border-bottom">
        <h3 className="display-4">All Courses</h3>
      </header>
      <div className="row">
        {courses.map((course) => (
          <div className="col-md-4" key={course.id}>
            <div className="card mb-4 shadow-sm">
              <img
                src={course.thumbnail || 'https://via.placeholder.com/300x200'}
                className="card-img-top"
                alt={course.title}
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body">
                <h5 className="card-title">{course.title}</h5>
                <p className="card-text">{course.description.substring(0, 100)}...</p>
                <div className="d-flex justify-content-between align-items-center">
                  <Link
                    to={'/course/' + course.id}
                    state={{ course: course }} // Pass course data in state
                    className="btn btn-sm btn-outline-secondary"
                  >
                    View Details
                  </Link>
                  <small className="text-muted fs-5">${course.price}</small>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CourseList;